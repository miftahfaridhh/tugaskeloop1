package tugasoop;
class omnivora extends hewan{
    public void makan(){
        System.out.println("Termasuk Hewan Pemakan Segalanya");
    }
}