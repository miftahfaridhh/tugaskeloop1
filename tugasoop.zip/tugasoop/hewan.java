package tugasoop;
class hewan {
    public void makan(){
        System.out.println("Jenis Makanan Hewan Ini Adalah");
    }
}