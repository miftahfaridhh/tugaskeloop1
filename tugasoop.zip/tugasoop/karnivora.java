package tugasoop;
class karnivora extends hewan{
    public void makan(){
        System.out.println("Termasuk Hewan Pemakan Daging");
    }
}