package tugasoop;
class herbivora extends hewan{
    public void makan(){
        System.out.println("Termasuk Hewan Pemakan Tumbuhan");
    }
}